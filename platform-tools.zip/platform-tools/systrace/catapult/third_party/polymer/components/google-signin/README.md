google-signin
================

See https://elements.polymer-project.org/elements/google-signin
